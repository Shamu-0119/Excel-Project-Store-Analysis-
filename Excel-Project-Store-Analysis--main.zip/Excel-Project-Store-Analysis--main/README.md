# Excel-Project-Store-Analysis-

Which month got the highest sales and ordres?
Who purchased more- men or women in 2022?
What are different order status in 2022?
List top 5 states contributing to the sales?
Relation between age and gender based on number of orders.
Which channel is contributing to maximum sales?
